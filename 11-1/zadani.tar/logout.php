<?php
    // zrusme session
?>