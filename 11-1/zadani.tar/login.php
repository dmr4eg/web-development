<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Moje app - prihlaseni</title>
</head>
<body>
    <form action="" method="post">
        <div>
            <label>
                Username:
                <input type="text" value=""  name="username">
            </label>
        </div>
        <div>
            <label>
                Password:
                <input type="password" name="password">
            </label>
        </div>

        <input type="submit" name="login" value="Prihlasit se">

        <?php
        
        ?>
    </form>
</body>
</html>